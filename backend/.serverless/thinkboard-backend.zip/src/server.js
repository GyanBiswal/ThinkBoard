// import express from "express";
// import cors from "cors";
// import dotenv from "dotenv";
// import path from "path";

// import notesRoutes from "./routes/notesRoutes.js";
// import { connectDB } from "./config/db.js";
// import rateLimiter from "./middleware/rateLimiter.js";

// dotenv.config();

// const app = express();
// const PORT = process.env.PORT || 5002;
// const __dirname = path.resolve();

// // middleware
// if (process.env.NODE_ENV !== "production") {
//   app.use(
//     cors({
//       origin: "http://localhost:5173",
//     })
//   );
// }
// app.use(express.json()); // this middleware will parse JSON bodies: req.body
// app.use(rateLimiter);


// // our simple custom middleware
// // app.use((req, res, next) => {
// //   console.log(`Req method is ${req.method} & Req URL is ${req.url}`);
// //   next();
// // });


// app.use("/api/notes", notesRoutes);

// if (process.env.NODE_ENV === "production") {
//   app.use(express.static(path.join(__dirname, "../frontend/dist")));

//   app.get("*", (req, res) => {
//     res.sendFile(path.join(__dirname, "../frontend", "dist", "index.html"));
//   });
// }

// connectDB().then(() => {
//   app.listen(PORT, () => {
//     console.log("Server started on PORT:", PORT);
//   });
// });


/*-----------------------------------------AWS--------------------------------------------------*/


import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";

import notesRoutes from "./routes/notesRoutes.js";
import { connectDB } from "./config/db.js";
import rateLimiter from "./middleware/rateLimiter.js";
import serverless from "serverless-http";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5002;
const __dirname = path.resolve();

// CORS Middleware
const allowedOrigins = [
  "http://localhost:5173",
  "http://thinkboard-frontend.s3-website.ap-south-1.amazonaws.com" // your S3 frontend
];

app.use(
  cors({
    origin: function(origin, callback){
      // allow requests with no origin (like mobile apps or Postman)
      if(!origin) return callback(null, true);
      if(allowedOrigins.indexOf(origin) === -1){
        const msg = `The CORS policy for this site does not allow access from the specified Origin.`;
        return callback(new Error(msg), false);
      }
      return callback(null, true);
    },
    methods: ["GET","POST","PUT","DELETE"],
    credentials: true
  })
);

app.use(express.json());
app.use(rateLimiter);

// API routes
app.use("/api/notes", notesRoutes);

// Serve frontend in production
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../frontend/dist")));

  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend/dist/index.html"));
  });
}

// Connect to DB
connectDB().then(() => {
  if (process.env.IS_OFFLINE !== "true") {
    app.listen(PORT, () => {
      console.log("Server started on PORT:", PORT);
    });
  }
});

// Export Lambda handler
export const handler = serverless(app);
